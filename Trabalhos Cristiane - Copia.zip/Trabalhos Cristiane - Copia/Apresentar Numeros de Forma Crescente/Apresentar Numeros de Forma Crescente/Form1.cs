﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Apresentar_Numeros_de_Forma_Crescente
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            float N1, N2, N3, troca;
            N1 = float.Parse(textBox1.Text);
            N2 = float.Parse(textBox2.Text);
            N3 = float.Parse(textBox3.Text);
            if (N1 > N2)
            {
                troca = N1;
                N1 = N2;
                N2 = troca;
            }

            if (N1 > N3)
            {
                troca = N1;
                N1 = N3;
                N3 = troca;
            }

            if (N2 > N3)
            {
                troca = N2;
                N2 = N3;
                N3 = troca;
            }
            label5.Text = N1 + " - " + N2 + " - " + N3;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            label5.Text = " ";
            textBox1.Focus();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
